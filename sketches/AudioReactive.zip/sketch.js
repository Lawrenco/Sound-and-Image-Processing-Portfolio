l1 = 0
l2 = 0

function preload() {
  sound = loadSound('flickshort.mp3');
  bit = loadFont('DS-DIGI.TTF');
}

function setup() {
  //frameRate(60);
  let cnv = createCanvas(750, 500, WEBGL);
  sound.play()
  sound.loop()
  fft = new p5.FFT();
  sound.amp(0.2);
  strokeWeight(3)
}

function draw() {
  background(0)
  fft.analyze(sound.mix);
  low = fft.getEnergy(20, 200);
  lowl = fft.getEnergy(20, 100);
  lowh = fft.getEnergy(100, 200);

  mid = fft.getEnergy(200, 2000);
  midl = fft.getEnergy(200, 1000);
  midh = fft.getEnergy(1000, 2000);

  high = fft.getEnergy(2000, 10000);
  highl = fft.getEnergy(2000, 5000);
  highh = fft.getEnergy(5000, 10000);

  l1 = lerp(l1, low, 0.7);
  l2 = lerp(l2, low * 2, 1);
  l3 = lerp(l2, midl * 0.05, 0.3);
  textFont(bit);



  if (lowh > 190) {

    background(255, 0, 100)
    push()
    fill(255)
    translate(-width / 2, -height / 2, -30)
    for (let j = 0; j < width; j = j + 10) {
      textSize(int(random(32)));
      stroke(0)
      text(int(low), j, random(height))
      text(int(high), j, random(height))
      text(int(mid), j, random(height))
    }
    pop()
    push();
    rotateX((frameCount * 0.005));
    rotateY((frameCount * 0.005));
    rotateZ((frameCount * 0.005));
    box(25, 25, l2*2);
    box(l2*2, 25, 25);
    box(25, l2*2, 25);
    pop();
    fill(0, 0, 0)
    stroke(0, 0, 0)
  } else {
    fill(0, 0, 0)
    stroke(low * 2, 0, low * 2)
    for (let i = 0; i < width; i = i + 120) {
      for (let k = 0; k < height; k = k + 120) {
        push();
        translate(-width / 2 + i, -height / 2 + k, 0)
        rotateX((frameCount * 0.005));
        rotateY((frameCount * 0.005));
        rotateZ((frameCount * 0.005));
        box(25, 25, l2);
        box(l2, 25, 25);
        box(25, l2, 25);
        pop();
      }
    }

  }

  if (midh > 150) {
    stroke(0)
    fill(random(255), 0, 100)
  }


  if (midh > 130) {
    f = int(random(0,5))
    push()
    translate(0, 10, 250)
    textSize(64)
    noStroke()
    fill(random(255))
    textAlign(CENTER)
    faces = ["+_+","^_^","#_#","0_0",">_<"]
    text(faces[f], 0, 0)
    pop()
  }
}