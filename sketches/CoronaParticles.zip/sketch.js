let nop = [];
let cases = [];
let recovered = [];
let deaths = [];
let data;
let xoff = 0.0;
let nx = 0;
let ny = 0;
let pick = 0;
let limit = 6500;

function preload() {
  data = loadJSON("https://coronavirus-19-api.herokuapp.com/countries", gotData);
}


function setup() {
  createCanvas(windowWidth, windowHeight);
  textFont("Rubik");
  let cas = (data[pick].cases - data[pick].recovered - data[pick].deaths)
  //print(cas);
  //print(cas);
 //print((data[pick].cases - data[pick].recovered - data[pick].deaths ) / 10)

  // for (let l = 0; l < 8822 - data[12].cases - data[12].deaths; l++) {
  //   nop.push(new Jitter());
  // }
  let mas = limit / data[pick].cases; 
  // print(limit)
  // print(data[pick].cases)
  // print(mas);
  // print(int(cas * mas));
  if (data[pick].cases  > limit) {
    for (let i = 0; i < int(cas * mas); i++) {      
      //print("limit2");
      cases.push(new Jitter());
    }
  }  
  else {
    for (let i = 0; i < int(cas); i++) {
      // print("none");
      cases.push(new Jitter());
    }
  }

print(int(data[pick].recovered * mas));
  if (data[pick].cases > limit) {
    for (let l = 0; l < int(data[pick].recovered * mas); l++) {
      recovered.push(new JitterD());
    }
    }
   else {
    for (let l = 0; l < data[pick].recovered; l++) {
      recovered.push(new JitterD());
    }
  }

print(int(data[pick].deaths * mas));
  if (data[pick].cases > limit) {
    for (let j = 0; j < int(data[pick].deaths * mas); j++) {
      deaths.push(new JitterD());
    }
  } 
  
  else {
  for (let j = 0; j < data[pick].deaths; j++) {
    deaths.push(new JitterD());
  }
}

}

function gotData(data) {
  //print(data[pick])

  //   for (let i = 0; i < 15; i++) {
  //   if (data[i].country == "Austria") {
  //     print("yes")
  //   }
  // }
}

function draw() {
  background(0);

  //   for (let l = 0; l < nop.length; l++) {
  //   fill(30)
  //     nop[l].move();
  //     nop[l].display();
  //   }

  for (let i = 0; i < cases.length; i++) {
    fill(200, 30, 200)
    cases[i].move();
    cases[i].display();
  }


  for (let l = 0; l < recovered.length; l++) {
    fill(0, 255, 0)
    recovered[l].moveD();
    recovered[l].displayD();
  }

  for (let j = 0; j < deaths.length; j++) {
    fill(255, 0, 0)
    deaths[j].moveD();
    deaths[j].displayD();
  }

  fill(0,80);
  rect(0,0,windowWidth, windowHeight);
  textSize(15);

  fill(255);
  text("COVID-19: " + data[pick].country, 20, 30);
  text(data[pick].cases + " Cases"  , 20, 50);
  text(data[pick].recovered + " Recovered" , 20, 70);
  text(data[pick].deaths + " Deaths", 20, 90);
  
  fill(255);
  rect(5,20,10, 10);
  
  fill(200, 30, 200);
  rect(5,40,10, 10);
  
  fill(0, 255, 0);
  rect(5,60,10, 10);
  
  fill(255, 0, 0);
  rect(5,80,10, 10);

}

// Jitter class
class Jitter {
  constructor() {

    this.x = random(width);
    this.y = random(height);
    this.diameter = random(5, 20);
    this.speed = 0.7;

  }

  move() {

    this.x += random(-this.speed, this.speed);
    this.y += random(-this.speed, this.speed);
  }

  display() {
    ellipse(this.x, this.y, this.diameter, this.diameter);
  }


}

// Jitter class
class JitterD {
  constructor() {

    this.x = random(width);
    this.y = random(height);
    this.diameter = random(10,20);
    this.speed = 0.7;

  }

  moveD() {

    this.x += random(-this.speed, this.speed);
    this.y += random(-this.speed, this.speed);
  }

  displayD() {
    ellipse(this.x, this.y, this.diameter, this.diameter);
  }


}