let x = 10;
let y = 10;
let num = 0.01
let c2 = "#1DF28F"
let c1 = "#770AA6"
let farb = ["#1DF28F",
            "#770AA6",
            "#F20544",
            "#F20574",
            "#0433BF",
           "#05C7F2"]



value = 0
counter = 0

function setup() {
  createCanvas(400, 800);
  rectMode(CENTER)
  fill(c1) 
  frameRate(30)
  circ = random(0,25) 
  dis = random(0,60)
  s = random(20,140)
  col1 = int(random(0,6))
  col2 = int(random(0,6))


  


}

function mousePressed() {
x = random(width)
y = random(height)
circ = random(0,25) 
dis = random(0,60)
rate = random(30,100);
s = random(20,140)
col1 = int(random(0,6))
col2 = int(random(0,6))
frameRate(rate)
}

function draw() {



  
  background(0); 
  //rect(width/2,0,10,height)
  counter = counter + num
  for (let i = 10; i < height; i = i + dis) {
      fill(farb[col1]) 
      rect(sin(counter+i*10)*10/2+width/2,i,sin(counter+i*10)*s,sin(counter+i*10)*s,circ)
      fill(farb[col2])
      rect(sin(counter+i*x)*y/2+width/2,i,sin(counter+i*x)*s,sin(counter+i*x)*s,circ)
  }
    //save('myCanvas.jpg');
}
