function setup() {
  createCanvas(800, 800);
  background(100);
  rectMode(CENTER);
  //colorMode(HSB);
  int(e = 0);
  //frameRate(15);
  noStroke();
  int(n = 20);
  int(m = 20);
  int(l = 20);
  int(rotata = 45);
  int(s = 3);
  int(c = 1);
  int(pick = 0);




}

function draw() {

  if (keyIsPressed === true) {
    n = random(10, 90);
    c = int(random(0, 255));
    m = random(10, 50);
    rotata = random(0, 90);
    s = int(random(0, 4));
    c = int(random(255));
    pick = int(random(0, 3));
    //print(s);
  }
  


  background(0);

  translate(m / 3, m / 3);

  for (let i = 0; i < height; i = i + n) {
    for (let j = 0; j < width; j = j + 10 + n) {
      if (e >= 320) e = 0;
      else e = e + 1;
      //let r=(sin(radians(e))*10);
      const myArray = [color(c, c, e), color(e, c, c), color(c, e, c)];
      fill(myArray[pick]);
      push();
      translate(j, i);
      rotate(radians(rotata));
      if (s == 0) {
        rec();
      }
      if (s == 1) {
        sph();
      }
      if (s == 2) {
        stroke(myArray[pick]);
        strokeWeight(s * 2);
        lin();
      }
      if (s == 3) {
        sph();
      }
      pop();

      push();
      translate(20 + j, 20 + i);
      rotate(radians(-rotata));
      if (s == 0) {
        rec();
      }
      if (s == 1) {
        sph();
      }
      if (s == 2) {
        //rotate(radians(rotata));	
        lin();
      }
      if (s == 3) {
        rec();
      }
      pop()
    }
  }

}

function rec() {
  rect(0, 0, m, n);
}

function sph() {
  ellipse(0, 0, m, n);
}

function lin() {
  line(0, 0, 0, c);
}

function touchStarted() {
    n = random(10, 90);
    c = int(random(0, 255));
    m = random(10, 50);
    rotata = random(0, 90);
    s = int(random(0, 4));
    c = int(random(255));
    pick = int(random(0, 3));
    //print(s);
}

function touchEnded() {
    n = random(10, 90);
    c = int(random(0, 255));
    m = random(10, 50);
    rotata = random(0, 90);
    s = int(random(0, 4));
    c = int(random(255));
    pick = int(random(0, 3));
    //print(s);
}